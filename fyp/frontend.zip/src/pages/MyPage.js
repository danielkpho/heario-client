import React from 'react';

const MyPage = () => {
  return (
    <div>
        <p>ENTER YOUR NAME<textarea></textarea></p>

        <p>PLAY</p>
        <p>CREATE PRIVATE ROOM</p>

        <p>ABOUT</p>

        <p>Hear.io is a free online multiplayer ear training game</p>
        <p>A normal game consists of a few rounds, where every player has to pick the correct note, chord or interval being played to gain points</p>
        <p>The person with the most points at the end of the game will then be crowned the winner! Have fun!</p>
    </div>
  );
  }

export default MyPage;